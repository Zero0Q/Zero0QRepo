# script.gtv.helper
Helper script for GTV skin
